Ubee Interactive
NDIS+RNDIS USB Drivers & InstallShield
Version 1.0 (first release)
Release Date: 7/31/2009

To install the USB drivers, please unzip Ubee USB_Driver_1.0 and execute "setup.exe". The InstallShield wizard will start and automatically install the USB drivers on your computer.

The following Ubee products are supported by this installer:

60194E - Windows 98SE, ME, 2K, XP and Vista
60678EU - Windows 98SE, ME, 2K, XP and Vista
60740EU/EUW - Windows 98SE, ME, 2K, XP and Vista
U10C018 - Windows 98SE, ME, 2K, XP and Vista
U10C019 - Windows 98SE, ME, 2K, XP and Vista
U10C020 - Windows 98SE, ME, 2K, XP and Vista
DDW2600 - Windows 2K, XP and Vista
U10C017 - Windows 98SE, ME, 2K, XP and Vista
U10C022 - Windows 2K, XP and Vista
U10C034 - Windows 2K, XP and Vista
DDC2700 - Windows 2K, XP and Vista
