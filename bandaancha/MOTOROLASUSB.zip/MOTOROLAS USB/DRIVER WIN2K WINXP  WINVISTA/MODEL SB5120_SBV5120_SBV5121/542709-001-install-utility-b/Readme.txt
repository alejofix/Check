*** Readme for Motorola SURFboard USB v1.2.0.2 Drivers ***

Motorola USB Driver Package for v1.2.0.2 (542709-001-install-utility-b.zip):

These drivers provide support for the following operating systems and devices.

The Motorola SURFboard USB v1.2.0.2 driver files in this release support the
following model modems, gateways and eMTAs, including Euro-DOCSIS and
International(i) variants for use with Windows 98se, Windows 2000, Windows Me,
and for both the 32-bit and 64-bit versions of Windows XP and Windows Vista:
	SB5120
	SBV5120
	SBV5121
	SBV5220
	SBV5222
	SBV5322
	HH1620

Motorola recommends that systems running 64-bit versions of these operating
systems use an Ethernet connection for the best performance and user experience.

All the above listed Operating Systems will report the USB driver file version
as v1.1.0.0 for this release.

The USB driver consists of eight files:
	rndismpk.sys
	rndismpm.sys
	rndismpw.sys
	RNDISMotCM.inf
	RNDISMotCM.cat
	usb8023k.sys
	usb8023m.sys
	usb8023w.sys

These file names must not be changed for successful interaction with the PC.

***NOTE*** During the installation of the drivers, Windows may pop up a warning
message; "Windows can't verify the publisher of this driver software". If this
happens, select the "install this driver anyway" option to complete the
installation.

"Microsoft and Windows are either registered trademarks or trademarks of
 Microsoft Corporation in the United States and/or other countries."
