*** Readme for Motorola SURFboard USB v2.4.1.7 Drivers ***

Motorola USB Driver Package for v2.4.1.7 (542708-001-install-utility-b.zip):
These drivers provide support for the following operating systems and devices.

The Motorola SURFboard USB v2.4.1.7 driver files in this release support the
following model modems and eMTAs, including Euro-DOCSIS and International(i)
variants for use with Windows 98se, Windows 2000, Windows Me, and for 32-bit
versions of Windows XP and Windows Vista:
	SB4100 / SB4101
	SB4200
	SB5100
	SB5101
	SBG900
	SBG940
	SBG1000
	SVG2500
	SBV5200
	
Motorola recommends that systems running 64-bit versions of these operating
systems use an Ethernet connection for the best performance and user experience.

The USB driver files in this release also supports the following modems for
64-bit versions of Windows XP and Windows Vista:
	SVG2500
	SBV5200

All the above listed Operating Systems will report the USB driver file version
as v1.30.0.0 for this release.

The USB driver set consists of five files:
	rndismpk.sys
	bcmndis.sys
	Motorola.cat
	NetMotCM.inf
	usb8023k.sys
These file names must not be changed for successful interaction with the PC.


***NOTE*** During the installation of the drivers, Windows may pop up a warning
message; "Windows can't verify the publisher of this driver software". If this
happens, select the "install this driver anyway" option to complete the
installation.

"Microsoft and Windows are either registered trademarks or trademarks of 
 Microsoft Corporation in the United States and/or other countries."