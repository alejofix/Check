******************************************************************
*            Cable Modem USB DRIVER DISK                         *
*            Copyright (C) 2007 ARRIS                            *
*            All Rights Reserved.                                *
******************************************************************

Contents of Disk:
1. AdbeRdr60_enu_full.exe : Adobe Acrobat reader version 6.0.1
2. ARRIS EULA.pdf : ARRIS End User License Agreement
3. attmusb.inf : ARRIS RNDIS USB Driver inf file
4. Microsoft License.txt : Microsoft Remote NDIS USB Driver licensing document
5. Readme.txt : this text file
6. rndismpm.sys : Remote NDIS Miniport for Windows Vista x64

================================================================================================
USB Un-installation:

Acrobat Reader Installation:
    To install Adobe Acrobat Reader 6.0.1 on Windows Vista x64,
    double click on AdbeRdr60_enu_full.exe file and follow the directions.

Technical Support for your Cable Modem:
    If you are a consumer who is experiencing difficulties with your internet connection,
    please contact your Cable Operator for support. 

    If you are a Cable Operator or other Service Provider,
    please send an email to modemsupport@arrisi.com