******************************************************************
*            Telephony Modem USB DRIVER DISK                     *
*            Copyright (C) 2006 ARRIS                            *
*            All Rights Reserved.                                *
******************************************************************


Contents of Disk:
1. ARRIS License.pdf : ARRIS Standard License Agreement and Limited Warranty
2. attmusb.cat : ARRIS WHQL certified catalog file
3. attmusb.inf : ARRIS RNDIS USB Driver inf file
4. Microsoft License.txt : Microsoft Remote NDIS USB Driver licensing document
5. Readme.txt : this file
6. remove.exe : Utility to remove Microsoft Remote NDIS USB Driver
7. remove.sys : support file to remove Microsoft Remote NDIS USB Driver from Device Manager
8. rndismpk.sys : Remote NDIS Miniport for Windows 2000
9. rndismpm.sys : Remote NDIS Miniport for Windows ME
10. rndismpw.sys : Remote NDIS Miniport for Windows 98/SE
11. usb8023k.sys : Microsoft Remote NDIS USB Driver for Windows 2000
12. usb8023m.sys : Microsoft Remote NDIS USB Driver for Windows ME
13. usb8023w.sys : Microsoft Remote NDIS USB Driver for Windows 98(SE)

================================================================================================
USB Un-installation:
    To uninstall USB drivers double click on the remove.exe file and follow the directions.

Technical Support for your Telephony Modem:
    If you are a consumer who is experiencing difficulties with your internet connection,
    please contact your Cable Operator for support. 

    If you are a Cable Operator or other Service Provider,
    please send an email to modemsupport@arrisi.com